package br.com.vinicius.ope_esmalteria

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TelaInicialActivity : DebugActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_inicial)
    }
}
